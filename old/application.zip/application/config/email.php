<?php

$config['protocol']      = 'smtp';
$config['smtp_host']     = 'localhost';
$config['smtp_user']     = 'info.ypkp';
$config['smtp_password'] = '1234';
$config['smtp_port']     = '587';
$config['smtp_keepalive']     = TRUE;
$config['newline']       = "\r\n";
$config['charset']       = 'utf-8';
$config['mailtype']      = 'html';
$config['wordwrap']      = TRUE;