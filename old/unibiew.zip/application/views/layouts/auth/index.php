<!DOCTYPE html>
<html>
<head>
<?php $this->load->view('layouts/auth/top-scripts.php'); ?>
</head>
<body class="hold-transition login-page" style="justify-content: start; padding-top: 100px;">

<?php $this->load->view($content); ?>

<?php $this->load->view('layouts/auth/bottom-scripts.php'); ?>

</body>
</html>
