<script>
// $(document).ready(function() {
//   $('#form-field-test_date').datetimepicker({format: 'YYYY-MM-DD'});
//   $('#form-field-test_period').datetimepicker({format: 'MM/YYYY'});
// });
</script>