<style>
.select2-results__option--highlighted .text-muted {
  color: #fff !important;
}
</style>